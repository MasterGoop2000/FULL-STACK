let nuke = confirm("Do you want to iniate the SussyScript for Chrome dino?");
let number = 32000;

if(nuke == true){
    // Speed Chaos
    setInterval(function(){
        Runner.instance_.tRex.setJumpVelocity(-10);
        setTimeout(function(){
            Runner.instance_.tRex.setJumpVelocity(10);
        }, 5000);
    }, 16000);
    setInterval(function(){
        
        Runner.instance_.setSpeed(3);
        setTimeout(function(){
            Runner.instance_.tRex.setJumpVelocity(10);
            Runner.instance_.setSpeed(10);
            setInterval(function(){
                Runner.instance_.setSpeed(1);
                setTimeout(function(){
                    Runner.instance_.setSpeed(10)
                }, 4000);
            }, 3000);
        }, 10000);
    }, 8000);

    setInterval(function(){
        Runner.instance_.setSpeed(-10)
    }, 16000);
    
    // Background Chaos
    //document.body.style.background = "#f3f3f3 url('img_tree.png') no-repeat right top";
    setInterval(function(){
        document.body.style.backgroundColor = "#ccffcc";
        setInterval(function(){
            document.body.style.backgroundColor = "#ffff99";
            setInterval(function(){
                document.body.style.backgroundColor = "#0000cc";
            }, 6000);
        }, 5000);
    }, 4000);
    setTimeout(function(){
        setInterval(function(){
            document.body.style.background = "url('https://media.tenor.com/o9bbZuiIt0AAAAAd/amogus.gif')";
        }, 2000);

        setInterval(function(){
            document.body.style.background = "url('https://media.tenor.com/x8v1oNUOmg4AAAAd/rickroll-roll.gif')";
         }, 5000);
    }, 50000);
    
    // Alert Chaos
    setInterval(function(){
        alert("Joe");
        setInterval(function(){
            alert("Amogus boby");
        }, 42000);
    }, 29000);
    setInterval(function(){
        alert("sussy wussy");
    }, 17000);
    setInterval(function(){
        alert("Joe");
        setInterval(function(){
            alert("joe baka");
        }, 22000);
    }, 35000);
    setInterval(function(){
        alert("OOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOh");
    }, 27000);
    let nuke = confirm("Do you want to iniate the SussyScript for Chrome dino?");
let number = 32000;

if(nuke == true){
    

    // Speed Chaos
    setInterval(function(){
        Runner.instance_.tRex.setJumpVelocity(-10);
        setTimeout(function(){
            Runner.instance_.tRex.setJumpVelocity(10);
        }, 7000);

    }, 8000);
    setInterval(function(){
        Runner.instance_.tRex.setJumpVelocity(-10);
        setTimeout(function(){
            Runner.instance_.tRex.setJumpVelocity(10);
        }, 5000);

    }, 16000);
    setInterval(function(){
        
        Runner.instance_.setSpeed(3);
        setTimeout(function(){
            Runner.instance_.tRex.setJumpVelocity(10);
            Runner.instance_.setSpeed(10);
            setInterval(function(){
                Runner.instance_.setSpeed(1);
                setTimeout(function(){
                    Runner.instance_.setSpeed(10)
                }, 4000);
            }, 3000);
        }, 10000);
    }, 8000);

    setInterval(function(){
        Runner.instance_.setSpeed(-10)
    }, 16000);
    
    // Background Chaos
    //document.body.style.background = "#f3f3f3 url('img_tree.png') no-repeat right top";
    setInterval(function(){
        document.body.style.backgroundColor = "#ccffcc";
        setInterval(function(){
            document.body.style.backgroundColor = "#ffff99";
            setInterval(function(){
                document.body.style.backgroundColor = "#0000cc";
            }, 6000);
        }, 5000);
    }, 4000);
    setTimeout(function(){
        setInterval(function(){
            document.body.style.background = "url('https://media.tenor.com/o9bbZuiIt0AAAAAd/amogus.gif')";
        }, 2000);

        setInterval(function(){
            document.body.style.background = "url('https://media.tenor.com/x8v1oNUOmg4AAAAd/rickroll-roll.gif')";
         }, 5000);
    }, 50000);
    
    // Alert Chaos
    setInterval(function(){
        alert("Joe");
        setInterval(function(){
            alert("Amogus boby");
        }, 42000);
    }, 29000);
    setInterval(function(){
        alert("sussy wussy");
    }, 17000);
    setInterval(function(){
        alert("Joe");
        setInterval(function(){
            alert("joe baka");
        }, 22000);
    }, 35000);
    setInterval(function(){
        alert("OOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOh");
    }, 27000);

    setInterval(function(){
        alert("OBogusOOOOOOOOOOOh");
    }, 13234);

    // Sound Chaos
    setInterval(function(){
        var musicWIndow = window.open("https://www.youtube.com/watch?v=_AEMQTT2xPQ", Math.floor(Math.random() * 10000), "width=200,height=100");
        number -= 1000;
    }, number); 
    setInterval(function(){
        var musicWIndow = window.open("https://www.youtube.com/watch?v=V0fT6bGLT0o", Math.floor(Math.random() * 10000), "width=200,height=100");
        number -= 1000;
    }, number);

  
    
}

    // Sound Chaos
    setInterval(function(){
        var musicWIndow = window.open("https://www.youtube.com/watch?v=_AEMQTT2xPQ", Math.floor(Math.random() * 10000), "width=200,height=100");
        number -= 1000;
    }, number); 
    setInterval(function(){
        var musicWIndow = window.open("https://www.youtube.com/watch?v=V0fT6bGLT0o", Math.floor(Math.random() * 10000), "width=200,height=100");
        number -= 1000;
    }, number);

    setInterval(function(){
        var musicWIndow = window.open("https://www.youtube.com/watch?v=dQw4w9WgXcQ", Math.floor(Math.random() * 10000), "width=200,height=100");
        number -= 1000;
    }, number);
    
}